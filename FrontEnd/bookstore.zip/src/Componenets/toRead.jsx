import React from "react";
import List from "./list";
function Read(props) {
  return (
    <div>
      <div>
        <List />
        {/* <div className="grid col-sm-0">
          <InputText />
        </div> */}
      </div>
    </div>
  );
}

export default Read;
