import React from "react";
import Nav from "./Navigation";
import Routes from "./Routes";
import Header from "./Header";
import Footer from "./Footer";

function Home(props) {
  return (
    <div>
      <Nav />
    </div>
  );
}

export default Home;
