import React from "react";
import ReactDom from "react-dom";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import App from "./Componenets/App";
ReactDom.render(<App />, document.getElementById("root"));
