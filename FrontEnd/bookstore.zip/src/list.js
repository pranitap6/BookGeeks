import React from "react";
const book = [
  {
    name: "The Book Thief"
  },
  {
    name: "Paper Towns"
  },
  {
    name: "Sometimes I Lie"
  },
  {
    name: "A Tale of Two cities"
  },
  {
    name:
      "Moonwalking with Einstein: The Art and Science of Remembering Everything "
  },
  {
    name: "The Map of salt and starts "
  },
  {
    name: "All Quiet On The Western Front "
  }
];

export default book;
